package src.playerTypes.ai_1;


import src.gameState.GameState;

public class State {

	
	public int store_player1;
	public int store_player2;
	
	public int[] houses;
	
	public int[] choiceOfMoves;
	public int[] moveWeight;
	
}

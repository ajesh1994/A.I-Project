package src.playerTypes.ai_2;

public class Path {

	
	public State initialState;
	public int move;
	public int reward;
	
	public Path(State initialState, int move){
		this.initialState = initialState;
		this.move = move;
	}
	
	
	
	
}

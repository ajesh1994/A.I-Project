package src.playerTypes.ai_2;

import java.util.ArrayList;

import src.gameState.GameState;

public class State extends GameState {

public State(){
	super();
}
	
}
